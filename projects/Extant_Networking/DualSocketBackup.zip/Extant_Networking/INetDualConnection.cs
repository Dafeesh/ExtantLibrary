﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Extant.Net
{
    public interface INetDualConnection : INetConnection
    {
        void Send(NetPacket packet, NetworkProtocol protocol);
    }
}
