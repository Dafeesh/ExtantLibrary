using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Extant.Logging;

namespace Extant.Net
{
    /// <summary>
    /// A network connection communicating via NetPackets.
    /// </summary>
    public interface INetConnection : IByteRecording, IDebugLogging
    {
        void Send(NetPacket packet);
        NetPacket Receive();
        void Close();

        bool PacketAvailable { get; }
        bool IsActive { get; }
        long TimeSinceLastPacket { get; }
    }
}
