using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

using Extant.Util;
using Extant.Threading;
using Extant.Logging;

namespace Extant.Net
{
    public class DualSocketConnection : INetConnection
    {
        private SocketConnection _tcpConnection;
        private SocketConnection _udpConnection;

        private DebugLogger _log;

        private DualSocketConnection(Socket tcpCon, Socket udpCon, NetPacket.PacketDecryptor decryptor)
        {
            this._log = new DebugLogger("DualSocket");

            this._tcpConnection = new SocketConnection(tcpCon, NetworkProtocol.TCP, decryptor,  _log);
            this._udpConnection = new SocketConnection(udpCon, NetworkProtocol.UDP, decryptor,  _log);
        }

        public static ConnectionProcess StartNew(IPEndPoint tcpEP, IPEndPoint udpEP, NetPacket.PacketDecryptor decryptor)
        {
            return ConnectionProcess.StartNew(tcpEP, udpEP, decryptor);
        }

        ////////////////////////////////////////////////

        public void Send(NetPacket packet)
        {
            Send(packet, NetworkProtocol.TCP);
        }

        public void Send(NetPacket packet, NetworkProtocol protocol)
        {
            switch (protocol)
            {
                case (NetworkProtocol.TCP):
                    _tcpConnection.Send(packet);
                    break;

                case (NetworkProtocol.UDP):
                    _udpConnection.Send(packet);
                    break;

                default:
                    throw new NotSupportedException("That protocol is not supported.");
            }
        }

        public NetPacket Receive()
        {
            //TCP
            if (_tcpConnection.PacketAvailable)
                return _tcpConnection.Receive();

            //UDP
            if (_udpConnection.PacketAvailable)
                return _udpConnection.Receive();

            //None
            return null;
        }

        public void Close()
        {
            _tcpConnection.Close();
            _udpConnection.Close();
        }

        ////////////////////////////////////////////////

        public bool IsActive
        {
            get
            {
                return (_tcpConnection.IsActive && _udpConnection.IsActive) || this.PacketAvailable;
            }
        }

        public bool PacketAvailable
        {
            get
            {
                return _tcpConnection.PacketAvailable || _udpConnection.PacketAvailable;
            }
        }

        public long TimeSinceLastPacket
        {
            get
            {
                return _tcpConnection.TimeSinceLastPacket < _udpConnection.TimeSinceLastPacket ?
                    _tcpConnection.TimeSinceLastPacket : _udpConnection.TimeSinceLastPacket;
            }
        }

        public IDebugLogger Log
        {
            get
            {
                return _log;
            }
        }

        ////////////////////////////////////////////////

        public class ConnectionProcess
        {
            public DualSocketConnection ClientConnection { get; private set; }
            public Step ConnectionStep { get; private set; }
            public bool IsDone { get; private set; }
            public ConnectionResult Result { get; private set; }
            public Exception Exception { get; private set; }

            private Thread _thread;
            private IPEndPoint _tcpEP;
            private IPEndPoint _udpEP;
            private NetPacket.PacketDecryptor _decryptor;

            private ConnectionProcess(IPEndPoint tcpEP, IPEndPoint udpEP, NetPacket.PacketDecryptor decryptor)
            {
                this._thread = new Thread(new ThreadStart(_Run));
                this._thread.Name = "ConnectingProcess";
                this._tcpEP = tcpEP;
                this._udpEP = udpEP;
                this._decryptor = decryptor;

                this.ClientConnection = null;
                this.ConnectionStep = Step.Waiting;
                this.IsDone = false;
                this.Result = ConnectionResult.Pending;
            }

            internal static ConnectionProcess StartNew(IPEndPoint tcpEP, IPEndPoint udpEP, NetPacket.PacketDecryptor decryptor)
            {
                ConnectionProcess cp = new ConnectionProcess(tcpEP, udpEP, decryptor);
                cp.Start();
                return cp;
            }

            public void Start()
            {
                _thread.Start();
            }

            public void Cancel()
            {
                _thread.Abort();
            }

            public void Wait()
            {
                while (!IsDone)
                { }
            }

            private void _Run()
            {
                TcpClient tcpClient = new TcpClient();
                UdpClient udpClient = new UdpClient();
                try
                {
                    try
                    {
                        ConnectionStep = Step.Connecting;
                        tcpClient.Connect(_tcpEP);
                    }
                    catch (SocketException e)
                    {
                        Result = ConnectionResult.SocketException;
                        this.Exception = e;
                        return;
                    }

                    if (tcpClient.Connected)
                    {
                        ConnectionStep = Step.Handshaking_TCP;

                        byte[] buffer = new byte[1028];
                        int received = tcpClient.Client.Receive(buffer);
                        if (received == sizeof(UInt32))
                        {
                            UInt32 token = BitConverter.ToUInt32(buffer, 0);

                            Thread.Sleep(100);

                            ConnectionStep = Step.Handshaking_UDP;

                            udpClient.Connect(_udpEP);
                            udpClient.Send(buffer, received);

                            IPEndPoint verifyUdpEndPoint = null;
                            byte[] verifyData = udpClient.Receive(ref verifyUdpEndPoint);
                            if (verifyData.Length == 1)
                            {
                                ConnectionStep = Step.Connected;

                                ClientConnection =
                                    new DualSocketConnection(
                                        tcpClient.Client,
                                        udpClient.Client,
                                        _decryptor);
                            }
                            else
                            {
                                Result = ConnectionResult.HandshakeFailed;
                                return;
                            }
                        }
                        else
                        {
                            Result = ConnectionResult.HandshakeFailed;
                            return;
                        }
                    }
                    else
                    {
                        Result = ConnectionResult.NoResponse;
                        return;
                    }
                }
                catch (Exception e)
                {
                    Result = ConnectionResult.UnknownException;
                    this.Exception = e;
                    return;
                }
                finally
                {
                    if (ClientConnection != null)
                    {
                        Result = ConnectionResult.Success;
                    }
                    else
                    {
                        try
                        {
                            tcpClient.Close();
                        }
                        catch { }
                        try
                        {
                            udpClient.Close();
                        }
                        catch { }

                        if (Result == ConnectionResult.Pending)
                            Result = ConnectionResult.UnknownFailure;
                    }

                    IsDone = true;
                }
            }

            public enum Step
            {
                Waiting,
                Connecting,
                Handshaking_TCP,
                Handshaking_UDP,
                Connected
            }

            public enum ConnectionResult
            {
                Pending,
                Success,
                NoResponse,
                SocketException,
                UnknownException,
                HandshakeFailed,
                UnknownFailure
            }
        }
    }
}
