﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Extant.Net
{
    public enum PacketDecryptionResult
    {
        Success,
        UnknownPacket,
        InterpretationError
    }
}
